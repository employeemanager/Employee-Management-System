package com.springboot.exception;

public class UserNotFoundException {

}
