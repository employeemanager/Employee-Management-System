export interface Employee {
    id: number;
    name: string;
    email: string;
    jobTitle: string;
    phone: string;
    img: string;
    empode: string;
  }